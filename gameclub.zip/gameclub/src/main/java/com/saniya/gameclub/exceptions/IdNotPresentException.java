package com.saniya.gameclub.exceptions;

public class IdNotPresentException extends Exception {
    public IdNotPresentException(String message){
        super(message);
    }
    
}

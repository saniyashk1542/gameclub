package com.saniya.gameclub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameclubApplicationTests {

	@Test
	void contextLoads() {
	}

}
